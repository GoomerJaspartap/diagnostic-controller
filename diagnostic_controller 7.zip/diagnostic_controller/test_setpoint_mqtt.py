#!/usr/bin/env python3
"""
MQTT Setpoint Strategy Test Script

This script helps test the setpoint strategy by sending MQTT messages
with setpoint values and current sensor readings.

Usage:
    python test_setpoint_mqtt.py

Features:
- Send test MQTT messages with setpoint and current values
- Simulate different scenarios (pass, over threshold, under threshold)
- Interactive mode to test different values
- Batch mode to send predefined test scenarios
"""

import paho.mqtt.client as mqtt
import json
import time
import random
import argparse
from datetime import datetime

# MQTT Configuration
MQTT_BROKER = "127.0.0.1"
MQTT_PORT = 1883
MQTT_TOPIC_PREFIX = "Thing/"

class SetpointMQTTTester:
    def __init__(self, broker=MQTT_BROKER, port=MQTT_PORT):
        self.broker = broker
        self.port = port
        self.client = None
        self.connected = False
        
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print(f"✅ Connected to MQTT broker at {self.broker}:{self.port}")
            self.connected = True
        else:
            print(f"❌ Failed to connect to MQTT broker. Return code: {rc}")
            self.connected = False
    
    def on_disconnect(self, client, userdata, rc):
        print(f"🔌 Disconnected from MQTT broker")
        self.connected = False
    
    def connect(self):
        """Connect to MQTT broker"""
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        
        try:
            self.client.connect(self.broker, self.port, 60)
            self.client.loop_start()
            time.sleep(1)  # Wait for connection
            return self.connected
        except Exception as e:
            print(f"❌ Error connecting to MQTT broker: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from MQTT broker"""
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
    
    def send_setpoint_message(self, sensor_id, setpoint_value, current_value, unit="°C", sensor_type="temperature"):
        """Send a test MQTT message with setpoint and current values"""
        if not self.connected:
            print("❌ Not connected to MQTT broker")
            return False
        
        # Create the message payload
        message = {
            "sensor_id": sensor_id,
            "sensor_type": sensor_type,
            "setpoint": setpoint_value,
            "value": current_value,
            "unit": unit,
            "timestamp": datetime.now().isoformat(),
            "test_mode": True
        }
        
        # Create topic
        topic = f"{MQTT_TOPIC_PREFIX}{sensor_type}/{sensor_id}"
        
        # Convert to JSON
        payload = json.dumps(message, indent=2)
        
        try:
            # Publish message
            result = self.client.publish(topic, payload, qos=1)
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"📤 Sent to {topic}:")
                print(f"   Setpoint: {setpoint_value} {unit}")
                print(f"   Current:  {current_value} {unit}")
                print(f"   Difference: {abs(current_value - setpoint_value):.2f} {unit}")
                return True
            else:
                print(f"❌ Failed to publish message. Error: {result.rc}")
                return False
                
        except Exception as e:
            print(f"❌ Error sending message: {e}")
            return False
    
    def test_scenario(self, scenario_name, sensor_id, setpoint_value, current_value, unit="°C", sensor_type="temperature"):
        """Test a specific scenario"""
        print(f"\n🧪 Testing Scenario: {scenario_name}")
        print("=" * 50)
        
        # Calculate deviation
        deviation = abs(current_value - setpoint_value)
        
        print(f"Sensor ID: {sensor_id}")
        print(f"Setpoint: {setpoint_value} {unit}")
        print(f"Current:  {current_value} {unit}")
        print(f"Deviation: {deviation:.2f} {unit}")
        
        # Send the message
        success = self.send_setpoint_message(sensor_id, setpoint_value, current_value, unit, sensor_type)
        
        if success:
            print(f"✅ Message sent successfully")
        else:
            print(f"❌ Failed to send message")
        
        return success

def run_interactive_mode(tester):
    """Run interactive testing mode"""
    print("\n🎮 Interactive Mode")
    print("=" * 50)
    print("Enter test parameters (press Enter for defaults)")
    
    while True:
        try:
            print("\n" + "-" * 30)
            
            # Get sensor ID
            sensor_id = input("Sensor ID (default: test_sensor_01): ").strip()
            if not sensor_id:
                sensor_id = "test_sensor_01"
            
            # Get sensor type
            sensor_type = input("Sensor type (temperature/humidity, default: temperature): ").strip().lower()
            if not sensor_type:
                sensor_type = "temperature"
            
            # Get unit
            unit = input("Unit (default: °C for temp, % for humidity): ").strip()
            if not unit:
                unit = "°C" if sensor_type == "temperature" else "%"
            
            # Get setpoint value
            setpoint_input = input("Setpoint value (default: 22.0): ").strip()
            setpoint_value = float(setpoint_input) if setpoint_input else 22.0
            
            # Get current value
            current_input = input("Current value (default: 23.5): ").strip()
            current_value = float(current_input) if current_input else 23.5
            
            # Send test message
            tester.test_scenario(
                "Interactive Test",
                sensor_id,
                setpoint_value,
                current_value,
                unit,
                sensor_type
            )
            
            # Ask if continue
            continue_test = input("\nContinue testing? (y/n, default: y): ").strip().lower()
            if continue_test in ['n', 'no']:
                break
                
        except KeyboardInterrupt:
            print("\n\n👋 Exiting interactive mode...")
            break
        except ValueError as e:
            print(f"❌ Invalid input: {e}")
        except Exception as e:
            print(f"❌ Error: {e}")

def run_batch_tests(tester):
    """Run predefined batch tests"""
    print("\n📦 Running Batch Tests")
    print("=" * 50)
    
    # Test scenarios
    test_scenarios = [
        # Temperature tests
        {
            "name": "Temperature - Within Threshold (Pass)",
            "sensor_id": "temp_room_01",
            "setpoint": 22.0,
            "current": 22.2,
            "unit": "°C",
            "type": "temperature"
        },
        {
            "name": "Temperature - Over Threshold (Fail)",
            "sensor_id": "temp_room_01", 
            "setpoint": 22.0,
            "current": 25.0,
            "unit": "°C",
            "type": "temperature"
        },
        {
            "name": "Temperature - Under Threshold (Fail)",
            "sensor_id": "temp_room_01",
            "setpoint": 22.0,
            "current": 19.0,
            "unit": "°C",
            "type": "temperature"
        },
        # Humidity tests
        {
            "name": "Humidity - Within Threshold (Pass)",
            "sensor_id": "hum_room_01",
            "setpoint": 50.0,
            "current": 51.0,
            "unit": "%",
            "type": "humidity"
        },
        {
            "name": "Humidity - Over Threshold (Fail)",
            "sensor_id": "hum_room_01",
            "setpoint": 50.0,
            "current": 65.0,
            "unit": "%",
            "type": "humidity"
        },
        {
            "name": "Humidity - Under Threshold (Fail)",
            "sensor_id": "hum_room_01",
            "setpoint": 50.0,
            "current": 35.0,
            "unit": "%",
            "type": "humidity"
        }
    ]
    
    # Run all test scenarios
    for i, scenario in enumerate(test_scenarios, 1):
        print(f"\n[{i}/{len(test_scenarios)}] {scenario['name']}")
        tester.test_scenario(**scenario)
        time.sleep(1)  # Wait between messages

def run_random_tests(tester, count=10):
    """Run random test scenarios"""
    print(f"\n🎲 Running {count} Random Tests")
    print("=" * 50)
    
    sensor_types = ["temperature", "humidity"]
    units = {"temperature": "°C", "humidity": "%"}
    
    for i in range(count):
        sensor_type = random.choice(sensor_types)
        unit = units[sensor_type]
        
        # Generate random values
        if sensor_type == "temperature":
            setpoint = round(random.uniform(18.0, 26.0), 1)
            current = round(random.uniform(15.0, 30.0), 1)
        else:  # humidity
            setpoint = round(random.uniform(40.0, 60.0), 1)
            current = round(random.uniform(30.0, 70.0), 1)
        
        sensor_id = f"random_{sensor_type}_{i+1:02d}"
        
        tester.test_scenario(
            f"Random Test {i+1}",
            sensor_id,
            setpoint,
            current,
            unit,
            sensor_type
        )
        time.sleep(0.5)  # Wait between messages

def main():
    parser = argparse.ArgumentParser(description="MQTT Setpoint Strategy Test Script")
    parser.add_argument("--broker", default=MQTT_BROKER, help="MQTT broker address")
    parser.add_argument("--port", type=int, default=MQTT_PORT, help="MQTT broker port")
    parser.add_argument("--mode", choices=["interactive", "batch", "random"], default="interactive",
                       help="Test mode")
    parser.add_argument("--count", type=int, default=10, help="Number of random tests (random mode only)")
    
    args = parser.parse_args()
    
    print("🚀 MQTT Setpoint Strategy Tester")
    print("=" * 50)
    print(f"Broker: {args.broker}:{args.port}")
    print(f"Mode: {args.mode}")
    
    # Create tester instance
    tester = SetpointMQTTTester(args.broker, args.port)
    
    # Connect to MQTT broker
    if not tester.connect():
        print("❌ Failed to connect to MQTT broker. Exiting...")
        return
    
    try:
        if args.mode == "interactive":
            run_interactive_mode(tester)
        elif args.mode == "batch":
            run_batch_tests(tester)
        elif args.mode == "random":
            run_random_tests(tester, args.count)
            
    except KeyboardInterrupt:
        print("\n\n👋 Test interrupted by user")
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
    finally:
        tester.disconnect()
        print("\n🔌 Disconnected from MQTT broker")

if __name__ == "__main__":
    main()
