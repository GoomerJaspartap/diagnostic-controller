import requests
import os
from dotenv import load_dotenv
import io
import datetime
import threading
import queue
import time
import base64

# Load environment variables
load_dotenv()

# Global email queue and worker thread
email_queue = queue.Queue()
email_worker_running = False
email_worker_thread = None

# Microsoft Graph API configuration
GRAPH_API_ENDPOINT = "https://graph.microsoft.com/v1.0"
TOKEN_ENDPOINT = "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

# Start the email worker thread automatically when module is imported
def _auto_start_worker():
    """Automatically start the email worker when module is imported"""
    try:
        start_email_worker()
    except Exception as e:
        print(f"[EMAIL WARNING] Could not auto-start email worker: {e}")

# Start worker thread automatically (moved after function definitions)

def get_access_token():
    """Get Microsoft Graph API access token using client credentials flow"""
    try:
        tenant_id = os.getenv('AZURE_TENANT_ID')
        client_id = os.getenv('AZURE_CLIENT_ID')
        client_secret = os.getenv('AZURE_CLIENT_SECRET')
        
        if not all([tenant_id, client_id, client_secret]):
            print("[EMAIL ERROR] Missing Azure credentials in environment variables")
            return None
        
        token_url = TOKEN_ENDPOINT.format(tenant_id=tenant_id)
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'scope': 'https://graph.microsoft.com/.default'
        }
        
        response = requests.post(token_url, data=data, timeout=30)
        response.raise_for_status()
        
        token_data = response.json()
        return token_data.get('access_token')
        
    except requests.exceptions.RequestException as e:
        print(f"[EMAIL ERROR] Failed to get access token: {e}")
        return None
    except Exception as e:
        print(f"[EMAIL ERROR] Unexpected error getting access token: {e}")
        return None

def start_email_worker():
    """Start the email worker thread if it's not already running"""
    global email_worker_running, email_worker_thread
    
    if not email_worker_running:
        email_worker_running = True
        email_worker_thread = threading.Thread(target=email_worker, daemon=True)
        email_worker_thread.start()
        print("[EMAIL DEBUG] Email worker thread started")
    else:
        print("[EMAIL DEBUG] Email worker thread already running")

def stop_email_worker():
    """Gracefully stop the email worker thread"""
    global email_worker_running
    
    if email_worker_running:
        print("[EMAIL DEBUG] Stopping email worker thread...")
        email_worker_running = False
        
        # Wait for the worker to finish processing current emails
        if email_worker_thread and email_worker_thread.is_alive():
            email_worker_thread.join(timeout=10)  # Wait up to 10 seconds
            
            if email_worker_thread.is_alive():
                print("[EMAIL WARNING] Email worker thread did not stop gracefully")
            else:
                print("[EMAIL DEBUG] Email worker thread stopped gracefully")
    else:
        print("[EMAIL DEBUG] Email worker thread not running")

def email_worker():
    """Background worker thread that processes email queue"""
    global email_worker_running
    
    print("[EMAIL DEBUG] Email worker thread started and running")
    
    while email_worker_running:
        try:
            # Get email task from queue with timeout
            try:
                email_task = email_queue.get(timeout=1.0)
            except queue.Empty:
                continue
            
            # Process the email
            recipients, subject, message, table_data, text, current_time = email_task
            
            print(f"[EMAIL DEBUG] Processing email for {recipients}...")
            
            # Send email synchronously in this thread
            success = _send_status_email_sync(recipients, subject, message, table_data, text, current_time)
            
            if success:
                print(f"[EMAIL DEBUG] Email sent successfully to {recipients}")
            else:
                print(f"[EMAIL ERROR] Failed to send email to {recipients}")
                
            # Mark task as done
            email_queue.task_done()
            
        except Exception as e:
            print(f"[EMAIL ERROR] Error in email worker: {e}")
            # Mark task as done even if it failed
            try:
                email_queue.task_done()
            except:
                pass
    
    print("[EMAIL DEBUG] Email worker thread stopped")

# Start worker thread automatically after all functions are defined
_auto_start_worker()

def get_email_queue_status():
    """Get current status of the email queue"""
    return {
        'queue_size': email_queue.qsize(),
        'worker_running': email_worker_running,
        'worker_alive': email_worker_thread.is_alive() if email_worker_thread else False
    }

def format_datetime(dt):
    if not dt:
        return ''
    if isinstance(dt, str):
        try:
            dt = datetime.datetime.fromisoformat(dt)
        except Exception:
            return dt
    return dt.strftime('%d %B, %Y %H:%M:%S')

def send_status_email(recipients, subject, message, table_data, text, current_time):
    """
    Asynchronous email sending - adds email to queue and returns immediately
    """
    # Start email worker if not running
    start_email_worker()
    
    # Add email task to queue
    email_task = (recipients, subject, message, table_data, text, current_time)
    email_queue.put(email_task)
    
    print(f"[EMAIL DEBUG] Email queued for {recipients} - will be sent asynchronously")
    return True

def _send_status_email_sync(recipients, subject, message, table_data, text, current_time):
    """
    Internal synchronous email sending function using Microsoft Graph API
    """
    # Get email credentials from environment variables
    sender_email = os.getenv('SENDER_EMAIL')
    
    print(f"[EMAIL DEBUG] Sending email from {sender_email} to {recipients}")
    
    if not sender_email:
        error_msg = "Sender email not found in environment variables"
        print(f"[EMAIL ERROR] {error_msg}")
        return False

    # Convert single recipient to list
    if isinstance(recipients, str):
        recipients = [recipients]
    
    # Get access token
    access_token = get_access_token()
    if not access_token:
        print("[EMAIL ERROR] Failed to obtain access token")
        return False
    
    # Load logo for attachment
    logo_attachment = None
    try:
        with open('static/logo.png', 'rb') as f:
            logo_data = f.read()
            logo_base64 = base64.b64encode(logo_data).decode('utf-8')
            logo_attachment = {
                "@odata.type": "#microsoft.graph.fileAttachment",
                "name": "logo.png",
                "contentType": "image/png",
                "contentBytes": logo_base64,
                "contentId": "logo001",
                "isInline": True
            }
            print("[EMAIL DEBUG] Logo loaded and prepared for attachment")
    except FileNotFoundError:
        print("[EMAIL WARNING] Logo file 'static/logo.png' not found. Email will be sent without logo.")
    except Exception as e:
        print(f"[EMAIL WARNING] Error reading logo file: {e}. Email will be sent without logo.")

    # HTML content with enhanced professional styling
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{subject}</title>
</head>
<body style="background: #f4f6fa; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #222; margin: 0; padding: 0;">
    <div style="max-width: 700px; margin: 40px auto; background: #fff; border-radius: 14px; border: 1px solid #e0e6ed; overflow: hidden;">
        <div style="background: #f8fafc; padding: 28px 32px 12px 32px; text-align: center; border-bottom: 1px solid #e0e6ed;">
            <a href="https://ace.ontariotechu.ca" target="_blank" style="display: inline-block; text-decoration: none;">
                <img src="cid:logo001" alt="ACE Logo" style="height: 44px; margin-bottom: 8px; max-width: 200px;">
            </a>
            <div style="font-size: 19px; color: #1a2a44; font-weight: 700; margin-bottom: 4px; letter-spacing: 0.5px;">Automotive Center of Excellence</div>
            <div style="font-size: 13px; color: #7f8c8d; letter-spacing: 1px;">Automated Diagnostics Report</div>
        </div>
        <div style="padding: 32px 24px 28px 24px;">
            <h1 style="color: #1a2a44; font-size: 27px; margin-bottom: 16px; text-align: center; letter-spacing: 0.5px;">Status Report</h1>
            <p style="font-size: 16px; margin-bottom: 22px; text-align: center; color: #444;">{message}</p>
            <div style="background: #f4f6fa; padding: 14px 18px; border-radius: 8px; margin-bottom: 28px; border: 1px solid #e0e6ed; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px; font-size: 15px;">
                <span><strong>Last Read Time:</strong> {format_datetime(current_time)}</span>
            </div>
"""
    for room, diagnostics in table_data.items():
        html += f"""
            <h2 style="color: #1a2a44; font-size: 19px; margin: 28px 0 12px 0; border-left: 3px solid #1a2a44; padding-left: 12px; letter-spacing: 0.2px;">Room: {room}</h2>
            <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 15px; background: #fff; border-radius: 6px;">
                <thead>
                    <tr style="background: #1a2a44; color: #fff;">
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Code</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Description</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Type</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">State</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Fault Type</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Strategy</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Current Value</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Start/Setpoint Field</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Target Value</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Threshold</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Time to Achieve</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Enabled At</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Last Read Time</th>
                        <th style="padding: 13px 8px; border-right: 1px solid #e0e6ed; text-align: left; font-weight: 600;">Last Failure</th>
                        <th style="padding: 13px 8px; text-align: left; font-weight: 600;">History</th>
                    </tr>
                </thead>
                <tbody>
"""
        for i, row in enumerate(diagnostics):
            state_color = {'Pass': '#2ecc71', 'Fail': '#e74c3c', 'NoStatus': '#7f8c8d'}.get(row['state'], '#7f8c8d')
            state_bg = {'Pass': '#eafaf1', 'Fail': '#fdeaea', 'NoStatus': '#f4f6fa'}.get(row['state'], '#f4f6fa')
            border_style = 'border-bottom: 1px solid #e0e6ed;' if i < len(diagnostics)-1 else ''
            # Format enabled_at with -4 hours if present
            enabled_at = row.get('enabled_at', 'N/A')
            if enabled_at and enabled_at != 'N/A':
                try:
                    from datetime import datetime, timedelta
                    if isinstance(enabled_at, str):
                        enabled_at_dt = datetime.fromisoformat(enabled_at)
                    else:
                        enabled_at_dt = enabled_at
                    enabled_at_shifted = (enabled_at_dt - timedelta(hours=4)).strftime('%Y-%m-%d %H:%M:%S')
                except Exception:
                    enabled_at_shifted = enabled_at
            else:
                enabled_at_shifted = 'N/A'
            # Get strategy information
            strategy = row.get('diagnostic_strategy', 'Threshold')
            setpoint_field = row.get('setpoint_json_field', '')
            
            # Determine what to show in the Start/Setpoint Field column
            if strategy == 'Setpoint':
                start_setpoint_value = setpoint_field if setpoint_field else 'N/A'
                target_value = 'N/A'  # Not used in setpoint strategy
                time_to_achieve = 'N/A'  # Not used in setpoint strategy
            else:
                start_setpoint_value = row.get('start_value', 'N/A')
                target_value = row.get('target_value', 'N/A')
                time_to_achieve = row.get('time_to_achieve', 'N/A')
            
            html += f"""                    <tr style="background: {state_bg}; {border_style}">
                        <td style="padding: 11px 8px;">{row['code']}</td>
                        <td style="padding: 11px 8px;">{row['description']}</td>
                        <td style="padding: 11px 8px;">{row['type']}</td>
                        <td style="padding: 11px 8px;">
                            <span style="display: inline-block; min-width: 54px; padding: 2px 10px; border-radius: 12px; background: {state_bg}; color: {state_color}; font-weight: 600; font-size: 14px; text-align: center;">{row['state']}</span>
                        </td>
                        <td style="padding: 11px 8px;">
                            <span style="display: inline-block; padding: 2px 8px; border-radius: 8px; background: {state_bg}; color: {state_color}; font-weight: 600; font-size: 12px; text-align: center;">{row.get('fault_type', 'N/A')}</span>
                        </td>
                        <td style="padding: 11px 8px;">
                            <span style="display: inline-block; padding: 2px 8px; border-radius: 8px; background: {'#e3f2fd' if strategy == 'Setpoint' else '#f3e5f5'}; color: {'#1976d2' if strategy == 'Setpoint' else '#7b1fa2'}; font-weight: 600; font-size: 12px; text-align: center;">{strategy}</span>
                        </td>
                        <td style="padding: 11px 8px;">{row.get('value', 'N/A')}</td>
                        <td style="padding: 11px 8px;">{start_setpoint_value}</td>
                        <td style="padding: 11px 8px;">{target_value}</td>
                        <td style="padding: 11px 8px;">{row.get('threshold', 'N/A')}</td>
                        <td style="padding: 11px 8px;">{time_to_achieve}</td>
                        <td style="padding: 11px 8px;">{enabled_at_shifted}</td>
                        <td style="padding: 11px 8px;">{row.get('last_read_time', 'N/A')}</td>
                        <td style="padding: 11px 8px;">{row['last_failure']}</td>
                        <td style="padding: 11px 8px;">{row.get('history_count', 'N/A')}</td>
                    </tr>
"""
        html += """                </tbody>
            </table>
            </div>
"""
    html += f"""            <div style="margin-top: 30px; padding-top: 18px; border-top: 1px solid #e0e6ed; text-align: center; color: #7f8c8d; font-size: 13px;">
                <div style="margin-bottom: 6px;">Generated on {format_datetime(current_time)}. Do not reply to this email.</div>
                <div style="font-size: 12px;">&copy; {datetime.now().year} Automotive Center of Excellence. All rights reserved.</div>
                <div style="margin-top: 4px;"><a href="https://ace.ontariotechu.ca" style="color: #1a2a44; text-decoration: none;">ace.ontariotechu.ca</a></div>
            </div>
        </div>
    </div>
    <style>
        @media only screen and (max-width: 800px) {{
            .container-table-wrap {{ overflow-x: auto; }}
            table {{ min-width: 600px; }}
        }}
    </style>
</body>
</html>"""

    try:
        print(f"[EMAIL DEBUG] Sending email via Microsoft Graph API...")
        
        # Prepare the email message for Microsoft Graph API
        email_data = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": "HTML",
                    "content": html
                },
                "toRecipients": [{"emailAddress": {"address": recipient}} for recipient in recipients],
                "from": {
                    "emailAddress": {
                        "address": sender_email
                    }
                }
            }
        }
        
        # Add logo attachment if available
        if logo_attachment:
            email_data["message"]["attachments"] = [logo_attachment]
        
        # Send email using Microsoft Graph API
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        # Use the sendMail endpoint
        send_url = f"{GRAPH_API_ENDPOINT}/users/{sender_email}/sendMail"
        
        response = requests.post(send_url, headers=headers, json=email_data, timeout=30)
        
        if response.status_code == 202:  # 202 Accepted is the expected response
            print(f"[EMAIL DEBUG] Email sent successfully via Microsoft Graph API!")
            return True
        else:
            print(f"[EMAIL ERROR] Failed to send email. Status: {response.status_code}, Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[EMAIL ERROR] Request failed: {e}")
        return False
    except Exception as e:
        print(f"[EMAIL ERROR] Unexpected error: {e}")
        return False 