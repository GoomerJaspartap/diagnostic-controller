import requests
import os
from dotenv import load_dotenv
import io
import datetime
import threading
import queue
import time
import base64

# Load environment variables
load_dotenv()

# Global email queue and worker thread
email_queue = queue.Queue()
email_worker_running = False
email_worker_thread = None

# Microsoft Graph API configuration
GRAPH_API_ENDPOINT = "https://graph.microsoft.com/v1.0"
TOKEN_ENDPOINT = "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

# Start the email worker thread automatically when module is imported
def _auto_start_worker():
    """Automatically start the email worker when module is imported"""
    try:
        start_email_worker()
    except Exception as e:
        print(f"[EMAIL WARNING] Could not auto-start email worker: {e}")

# Start worker thread automatically (moved after function definitions)

def get_access_token():
    """Get Microsoft Graph API access token using client credentials flow"""
    try:
        tenant_id = os.getenv('AZURE_TENANT_ID')
        client_id = os.getenv('AZURE_CLIENT_ID')
        client_secret = os.getenv('AZURE_CLIENT_SECRET')
        
        if not all([tenant_id, client_id, client_secret]):
            print("[EMAIL ERROR] Missing Azure credentials in environment variables")
            return None
        
        token_url = TOKEN_ENDPOINT.format(tenant_id=tenant_id)
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'scope': 'https://graph.microsoft.com/.default'
        }
        
        response = requests.post(token_url, data=data, timeout=30)
        response.raise_for_status()
        
        token_data = response.json()
        return token_data.get('access_token')
        
    except requests.exceptions.RequestException as e:
        print(f"[EMAIL ERROR] Failed to get access token: {e}")
        return None
    except Exception as e:
        print(f"[EMAIL ERROR] Unexpected error getting access token: {e}")
        return None

def start_email_worker():
    """Start the email worker thread if it's not already running"""
    global email_worker_running, email_worker_thread
    
    if not email_worker_running:
        email_worker_running = True
        email_worker_thread = threading.Thread(target=email_worker, daemon=True)
        email_worker_thread.start()
        print("[EMAIL DEBUG] Email worker thread started")
    else:
        print("[EMAIL DEBUG] Email worker thread already running")

def stop_email_worker():
    """Gracefully stop the email worker thread"""
    global email_worker_running
    
    if email_worker_running:
        print("[EMAIL DEBUG] Stopping email worker thread...")
        email_worker_running = False
        
        # Wait for the worker to finish processing current emails
        if email_worker_thread and email_worker_thread.is_alive():
            email_worker_thread.join(timeout=10)  # Wait up to 10 seconds
            
            if email_worker_thread.is_alive():
                print("[EMAIL WARNING] Email worker thread did not stop gracefully")
            else:
                print("[EMAIL DEBUG] Email worker thread stopped gracefully")
    else:
        print("[EMAIL DEBUG] Email worker thread not running")

def email_worker():
    """Background worker thread that processes email queue"""
    global email_worker_running
    
    print("[EMAIL DEBUG] Email worker thread started and running")
    
    while email_worker_running:
        try:
            # Get email task from queue with timeout
            try:
                email_task = email_queue.get(timeout=1.0)
            except queue.Empty:
                continue
            
            # Process the email
            recipients, subject, message, table_data, text, current_time = email_task
            
            print(f"[EMAIL DEBUG] Processing email for {recipients}...")
            
            # Send email synchronously in this thread
            success = _send_status_email_sync(recipients, subject, message, table_data, text, current_time)
            
            if success:
                print(f"[EMAIL DEBUG] Email sent successfully to {recipients}")
            else:
                print(f"[EMAIL ERROR] Failed to send email to {recipients}")
                
            # Mark task as done
            email_queue.task_done()
            
        except Exception as e:
            print(f"[EMAIL ERROR] Error in email worker: {e}")
            # Mark task as done even if it failed
            try:
                email_queue.task_done()
            except:
                pass
    
    print("[EMAIL DEBUG] Email worker thread stopped")

# Start worker thread automatically after all functions are defined
_auto_start_worker()

def get_email_queue_status():
    """Get current status of the email queue"""
    return {
        'queue_size': email_queue.qsize(),
        'worker_running': email_worker_running,
        'worker_alive': email_worker_thread.is_alive() if email_worker_thread else False
    }

def format_datetime(dt):
    if not dt:
        return ''
    if isinstance(dt, str):
        try:
            dt = datetime.datetime.fromisoformat(dt)
        except Exception:
            return dt
    return dt.strftime('%d %B, %Y %H:%M:%S')

def send_status_email(recipients, subject, message, table_data, text, current_time):
    """
    Asynchronous email sending - adds email to queue and returns immediately
    """
    # Start email worker if not running
    start_email_worker()
    
    # Add email task to queue
    email_task = (recipients, subject, message, table_data, text, current_time)
    email_queue.put(email_task)
    
    print(f"[EMAIL DEBUG] Email queued for {recipients} - will be sent asynchronously")
    return True

def _send_status_email_sync(recipients, subject, message, table_data, text, current_time):
    """
    Internal synchronous email sending function using Microsoft Graph API
    """
    # Get email credentials from environment variables
    sender_email = os.getenv('SENDER_EMAIL')
    
    print(f"[EMAIL DEBUG] Sending email from {sender_email} to {recipients}")
    
    if not sender_email:
        error_msg = "Sender email not found in environment variables"
        print(f"[EMAIL ERROR] {error_msg}")
        return False

    # Convert single recipient to list
    if isinstance(recipients, str):
        recipients = [recipients]
    
    # Get access token
    access_token = get_access_token()
    if not access_token:
        print("[EMAIL ERROR] Failed to obtain access token")
        return False
    
    # Load logo for attachment
    logo_attachment = None
    try:
        with open('static/logo.png', 'rb') as f:
            logo_data = f.read()
            logo_base64 = base64.b64encode(logo_data).decode('utf-8')
            logo_attachment = {
                "@odata.type": "#microsoft.graph.fileAttachment",
                "name": "logo.png",
                "contentType": "image/png",
                "contentBytes": logo_base64,
                "contentId": "logo001",
                "isInline": True
            }
            print("[EMAIL DEBUG] Logo loaded and prepared for attachment")
    except FileNotFoundError:
        print("[EMAIL WARNING] Logo file 'static/logo.png' not found. Email will be sent without logo.")
    except Exception as e:
        print(f"[EMAIL WARNING] Error reading logo file: {e}. Email will be sent without logo.")

    # Helper function to escape HTML special characters
    def escape_html(text):
        if text is None:
            return 'N/A'
        text = str(text)
        return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
    
    # Helper function to format seconds to hours:mins:sec
    def format_time_to_achieve(seconds):
        """Convert seconds to hours:mins:sec format"""
        if seconds is None or seconds == 'N/A':
            return 'N/A'
        try:
            seconds_int = int(float(seconds))
            hours = seconds_int // 3600
            minutes = (seconds_int % 3600) // 60
            secs = seconds_int % 60
            # Always show in hours:mins:sec format
            return f"{hours}:{minutes:02d}:{secs:02d}"
        except (ValueError, TypeError):
            return str(seconds) if seconds else 'N/A'
    
    # Helper function to determine border color and status text
    def get_fault_style(state, fault_type):
        """Returns border color and status text based on state and fault_type"""
        state_normalized = str(state).strip() if state else ''
        fault_type_normalized = str(fault_type).strip() if fault_type else ''
        
        # Check for No Status first
        if state_normalized in ('No Status', 'NoStatus'):
            return '#FACC15', 'No Status'  # Yellow border
        
        # Check fault type for Over/Under Threshold (prioritize fault_type if available)
        if fault_type_normalized:
            if 'Over Threshold' in fault_type_normalized:
                return '#EF4444', 'Over Threshold'  # Red border
            elif 'Under Threshold' in fault_type_normalized:
                return '#EF4444', 'Under Threshold'  # Red border
            elif 'Over Target' in fault_type_normalized:
                return '#EF4444', 'Over Target'  # Red border
            elif 'Out of Bounds' in fault_type_normalized:
                return '#EF4444', 'Out of Bounds'  # Red border
            # If fault_type exists but doesn't match known patterns, use it
            elif state_normalized == 'Fail':
                return '#EF4444', fault_type_normalized
        
        # Default to red for Fail states
        if state_normalized == 'Fail':
            return '#EF4444', fault_type_normalized if fault_type_normalized else 'Fail'
        
        # Default fallback - should not happen for fault emails, but handle gracefully
        return '#EF4444', fault_type_normalized if fault_type_normalized else state_normalized
    
    # Helper function to calculate expected value
    def get_expected_value(row):
        """Calculate expected value based on strategy
        First checks if expected_value was already calculated and passed in the row
        """
        # First, check if expected_value was already calculated and passed in the row
        if 'expected_value' in row and row['expected_value'] is not None:
            expected_val = row['expected_value']
            return f"{float(expected_val):.2f}" if isinstance(expected_val, (int, float)) else str(expected_val)
        
        strategy = row.get('diagnostic_strategy', 'Threshold')
        
        if strategy == 'Setpoint':
            # For setpoint strategy, expected is the setpoint value
            setpoint_field = row.get('setpoint_json_field', '')
            # Try to get setpoint value from the row if available
            setpoint_value = row.get('setpoint_value') or row.get('target_value')
            if setpoint_value is not None:
                return str(setpoint_value)
            return setpoint_field if setpoint_field else 'N/A'
        else:
            # For threshold strategy, expected is the target value
            target_value = row.get('target_value')
            if target_value is not None:
                return str(target_value)
            return 'N/A'
    
    # Collect all diagnostics from all rooms into a flat list
    all_diagnostics = []
    for room, diagnostics in table_data.items():
        for diag in diagnostics:
            all_diagnostics.append(diag)
    
    # HTML content with new template design
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Fault Alerts Notification</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:AllowPNG/>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]--><style>
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        body { margin: 0; padding: 0; }
        p { margin: 0; padding: 0; }
        img { max-width: 100%; height: auto; display: block; }
    </style>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f7fa; font-family: Arial, sans-serif;">
    <!-- Outer wrapper table for background and center alignment --><table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background-color: #f4f7fa;">
        <tr>
            <td align="center" style="padding: 20px 0;">
                <!-- Main Content Container (600px wide) --><table width="600" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width: 600px; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                    
                    <!-- 1. HEADER & LOGO --><tr>
                        <td style="padding: 20px 30px 10px 30px; background-color: #003366; border-radius: 8px 8px 0 0;">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                <tr>
                                    <td align="left" style="vertical-align: middle;">
                                        <img src="cid:logo001" alt="ACE Team Logo" style="display: block; width: 100px; height: auto; border: 0;">
                                    </td>
                                    <td align="right" style="vertical-align: middle;">
                                        <p style="font-family: Arial, sans-serif; font-size: 28px; color: #ffffff; font-weight: bold; margin: 0;">
                                            Fault Alerts
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- 2. INTRO MESSAGE --><tr>
                        <td style="padding: 30px 30px 20px 30px;">
                            <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 0 0 10px 0; line-height: 24px;">
                                Dear Team,
                            </p>
                            <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 0; line-height: 24px;">
                                The following fault conditions have been detected by the system:
                            </p>
                        </td>
                    </tr>
"""
    
    # 3. FAULT ENTRIES LOOP - Create a card for each diagnostic
    for row in all_diagnostics:
        # Format enabled_at with -4 hours if present
        enabled_at = row.get('enabled_at', 'N/A')
        if enabled_at and enabled_at != 'N/A':
            try:
                from datetime import datetime, timedelta
                if isinstance(enabled_at, str):
                    enabled_at_dt = datetime.fromisoformat(enabled_at)
                else:
                    enabled_at_dt = enabled_at
                enabled_at_shifted = (enabled_at_dt - timedelta(hours=4)).strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                enabled_at_shifted = str(enabled_at) if enabled_at else 'N/A'
        else:
            enabled_at_shifted = 'N/A'
        
        # Get fault style (border color and status text)
        border_color, status_text = get_fault_style(row.get('state'), row.get('fault_type'))
        
        # Get values
        fault_type = row.get('type', 'N/A')
        chamber_name = row.get('room_name', 'Unassigned')
        fault_code = row.get('code', 'N/A')
        current_value = row.get('value', 'N/A')
        if current_value is not None:
            current_value = str(current_value)
        else:
            current_value = 'N/A'
        expected_value = get_expected_value(row)
        description = row.get('description', 'N/A')
        time_to_achieve_raw = row.get('time_to_achieve', 'N/A')
        time_to_achieve = format_time_to_achieve(time_to_achieve_raw)
        last_read_at = row.get('last_read_time', 'N/A')
        threshold_limit = row.get('threshold', 'N/A')
        if threshold_limit is not None:
            threshold_limit = str(threshold_limit)
        else:
            threshold_limit = 'N/A'
        start_value = row.get('start_value', 'N/A')
        if start_value is not None:
            start_value = str(start_value)
        else:
            start_value = 'N/A'
        target_value = row.get('target_value', 'N/A')
        if target_value is not None:
            target_value = str(target_value)
        else:
            target_value = 'N/A'
        
        # Escape HTML special characters
        fault_type = escape_html(fault_type)
        chamber_name = escape_html(chamber_name)
        fault_code = escape_html(fault_code)
        current_value = escape_html(current_value)
        expected_value = escape_html(expected_value)
        description = escape_html(description)
        time_to_achieve = escape_html(time_to_achieve)
        enabled_at_shifted = escape_html(enabled_at_shifted)
        last_read_at = escape_html(last_read_at)
        threshold_limit = escape_html(threshold_limit)
        start_value = escape_html(start_value)
        target_value = escape_html(target_value)
        status_text = escape_html(status_text)
        
        html += f"""
                    <!-- FAULT ENTRY --><tr>
                        <td style="padding: 0 30px 20px 30px;">
                            <!-- Individual Fault Card -->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background-color: #f8f9fa; border: 1px solid #e5e7eb; border-left: 5px solid {border_color}; border-radius: 6px; margin-bottom: 20px;">
                                <tr>
                                    <td style="padding: 20px;">
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                            <tr>
                                                <td colspan="2" style="padding-bottom: 5px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 18px; color: #003366; margin: 0; font-weight: bold;">
                                                        {fault_type}
                                                        <span style="float: right; font-size: 16px; color: {border_color}; font-weight: bold;">{status_text}</span>
                                                    </p>
                                                </td>
                                            </tr>
                                            <!-- Chamber Name and Fault Code -->
                                            <tr>
                                                <td width="50%" style="padding-bottom: 10px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Chamber Name</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0; font-weight: bold;">
                                                        {chamber_name}
                                                    </p>
                                                </td>
                                                <td width="50%" style="padding-bottom: 10px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Fault Code</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0; font-weight: bold;">
                                                        {fault_code}
                                                    </p>
                                                </td>
                                            </tr>
                                            <!-- Current/Expected Value Summary -->
                                            <tr>
                                                <td width="50%" style="padding-bottom: 15px; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Current Value</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 18px; color: #1f2937; margin: 5px 0 0 0; font-weight: bold;">
                                                        {current_value}
                                                    </p>
                                                </td>
                                                <td width="50%" style="padding-bottom: 15px; border-top: 1px solid #e5e7eb; padding-top: 15px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Expected Value</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 18px; color: #1f2937; margin: 5px 0 0 0; font-weight: bold;">
                                                        {expected_value}
                                                    </p>
                                                </td>
                                            </tr>
                                            
                                            <!-- Description -->
                                            <tr>
                                                <td colspan="2" style="padding-bottom: 10px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0 0 3px 0; font-weight: bold;">
                                                        Description:
                                                    </p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #1f2937; margin: 0; line-height: 20px;">
                                                        {description}
                                                    </p>
                                                </td>
                                            </tr>

                                            <!-- Time to Achieve & Enabled At -->
                                            <tr>
                                                <td width="50%" style="padding: 10px 0; border-top: 1px solid #e5e7eb;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Time to Achieve</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {time_to_achieve}
                                                    </p>
                                                </td>
                                                <td width="50%" style="padding: 10px 0; border-top: 1px solid #e5e7eb;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Enabled At</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {enabled_at_shifted}
                                                    </p>
                                                </td>
                                            </tr>

                                            <!-- Last Read At & Threshold Limit -->
                                            <tr>
                                                <td width="50%" style="padding-top: 10px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Last Read At</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {last_read_at}
                                                    </p>
                                                </td>
                                                <td width="50%" style="padding-top: 10px;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Threshold Limit</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {threshold_limit}
                                                    </p>
                                                </td>
                                            </tr>

                                            <!-- Start Value & Target Value -->
                                            <tr>
                                                <td width="50%" style="padding-top: 10px; border-top: 1px solid #e5e7eb;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Start Value</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {start_value}
                                                    </p>
                                                </td>
                                                <td width="50%" style="padding-top: 10px; border-top: 1px solid #e5e7eb;">
                                                    <p style="font-family: Arial, sans-serif; font-size: 14px; color: #6b7280; margin: 0;">Target Value</p>
                                                    <p style="font-family: Arial, sans-serif; font-size: 16px; color: #1f2937; margin: 2px 0 0 0;">
                                                        {target_value}
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
"""
    
    html += """
                </table>

            </td>
        </tr>
    </table>
</body>
</html>"""

    try:
        print(f"[EMAIL DEBUG] Sending email via Microsoft Graph API...")
        
        # Prepare the email message for Microsoft Graph API
        email_data = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": "HTML",
                    "content": html
                },
                "toRecipients": [{"emailAddress": {"address": recipient}} for recipient in recipients],
                "from": {
                    "emailAddress": {
                        "address": sender_email
                    }
                }
            }
        }
        
        # Add logo attachment if available
        if logo_attachment:
            email_data["message"]["attachments"] = [logo_attachment]
        
        # Send email using Microsoft Graph API
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        # Use the sendMail endpoint
        send_url = f"{GRAPH_API_ENDPOINT}/users/{sender_email}/sendMail"
        
        response = requests.post(send_url, headers=headers, json=email_data, timeout=30)
        
        if response.status_code == 202:  # 202 Accepted is the expected response
            print(f"[EMAIL DEBUG] Email sent successfully via Microsoft Graph API!")
            return True
        else:
            print(f"[EMAIL ERROR] Failed to send email. Status: {response.status_code}, Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[EMAIL ERROR] Request failed: {e}")
        return False
    except Exception as e:
        print(f"[EMAIL ERROR] Unexpected error: {e}")
        return False 