# MQTT Listener - Diagnostic Controller

## Overview

The MQTT Listener is a web-based interface integrated into the Diagnostic Controller that allows users to monitor MQTT messages in real-time. It provides a user-friendly way to connect to MQTT brokers, configure connection settings, and view incoming messages with a modern, responsive interface.

## Features

### 🔌 Connection Management
- **Configurable Broker Settings**: Set broker IP address, port, and topic filter
- **Connect/Disconnect Controls**: Easy-to-use buttons to start and stop MQTT connections
- **Real-time Status**: Live connection status indicator
- **Dynamic Configuration**: Change broker settings without restarting the application

### 📡 Message Monitoring
- **Real-time Display**: Messages appear instantly as they're received
- **Topic Filtering**: Subscribe to all topics (#) or specific topics
- **Message Formatting**: Automatic JSON parsing and display
- **Timestamp Tracking**: Each message shows when it was received
- **Message History**: Stores up to 1000 recent messages

### 🎨 User Interface
- **Modern Design**: Clean, responsive interface with gradient buttons
- **Message Cards**: Each message displayed in an organized card format
- **Auto-scroll**: Option to automatically scroll to new messages
- **Clear Messages**: Button to clear the message display
- **Mobile Responsive**: Works on both desktop and mobile devices

## How to Use

### 1. Access the MQTT Listener
- Navigate to the **MQTT Listener** page from the main navigation
- Or use the **Quick Access Tools** section on the dashboard

### 2. Configure Connection
- Enter the **Broker IP Address** (e.g., `10.160.1.248`)
- Set the **Port** (default: `1883`)
- Choose a **Topic Filter** (`#` for all topics, or specific topic)

### 3. Connect and Monitor
- Click **Connect** to establish the MQTT connection
- Watch for incoming messages in real-time
- Use **Disconnect** to stop receiving messages
- **Clear** messages to reset the display

### 4. Message Display
- Messages are shown with topic badges and timestamps
- JSON payloads are automatically formatted for readability
- Raw text payloads are displayed as-is
- Binary data is converted to string representation

## Technical Details

### Backend Implementation
- **Flask Routes**: RESTful API endpoints for MQTT operations
- **Global MQTT Client**: Single MQTT client instance managed by the application
- **Message Queue**: Thread-safe queue storing recent messages
- **Connection Management**: Automatic reconnection and error handling

### API Endpoints
- `GET /mqtt_listener` - Main interface page
- `POST /api/mqtt/connect` - Connect to MQTT broker
- `POST /api/mqtt/disconnect` - Disconnect from broker
- `GET /api/mqtt/status` - Get connection status
- `GET /api/mqtt/messages` - Get recent messages

### Frontend Features
- **Real-time Updates**: Polling-based message retrieval
- **Responsive Design**: Bootstrap-based responsive layout
- **Interactive Controls**: Dynamic button states and loading indicators
- **Toast Notifications**: User feedback for connection events

## Configuration

### Default Settings
- **Broker**: `10.160.1.248`
- **Port**: `1883`
- **Topic**: `#` (all topics)
- **Keepalive**: `60` seconds
- **Message Buffer**: `1000` messages

### Customization
- Change broker settings through the web interface
- Modify topic filters for specific monitoring needs
- Adjust message buffer size in the backend code

## Security

- **Authentication Required**: All MQTT endpoints require user login
- **Session Management**: Uses Flask session-based authentication
- **Input Validation**: Broker settings are validated before connection

## Troubleshooting

### Common Issues

1. **Connection Failed**
   - Verify broker IP address and port
   - Check network connectivity
   - Ensure MQTT broker is running

2. **No Messages Received**
   - Verify topic filter settings
   - Check if messages are being published to the broker
   - Ensure proper MQTT permissions

3. **Interface Not Loading**
   - Check browser console for JavaScript errors
   - Verify Flask application is running
   - Check authentication status

### Debug Information
- Check Flask application logs for MQTT connection details
- Use browser developer tools to monitor API calls
- Verify MQTT broker logs for connection attempts

## Integration

The MQTT Listener is fully integrated with the Diagnostic Controller:

- **Navigation**: Added to main navigation menu
- **Dashboard**: Quick access from dashboard tools
- **Authentication**: Uses existing user authentication system
- **Styling**: Consistent with application design theme

## Future Enhancements

Potential improvements for future versions:

- **Multiple Broker Support**: Connect to multiple MQTT brokers simultaneously
- **Message Filtering**: Advanced filtering by topic, payload content, or timestamp
- **Data Export**: Export message logs to CSV or JSON
- **Alerting**: Configure alerts for specific message patterns
- **Message Templates**: Predefined message format templates
- **Historical Data**: Store messages in database for long-term analysis

## Dependencies

- **Backend**: `paho-mqtt`, `flask`, `psycopg2-binary`
- **Frontend**: Bootstrap 5, Font Awesome, vanilla JavaScript
- **Python**: Python 3.7+ required

## Support

For issues or questions regarding the MQTT Listener:

1. Check the troubleshooting section above
2. Review Flask application logs
3. Verify MQTT broker configuration
4. Test with a simple MQTT client to isolate issues
