# MQTT Setpoint Strategy Testing

This directory contains tools to test the setpoint strategy functionality by sending MQTT messages with setpoint and current values.

## Files

- `test_setpoint_mqtt.py` - Main testing script
- `test_requirements.txt` - Python dependencies
- `MQTT_TESTING_README.md` - This documentation

## Setup

1. Install dependencies:
```bash
pip install -r test_requirements.txt
```

2. Make sure your MQTT broker is running (default: localhost:1883)

## Usage

### Interactive Mode (Default)
```bash
python test_setpoint_mqtt.py
```

This mode allows you to:
- Enter custom sensor IDs
- Set different setpoint and current values
- Test both temperature and humidity sensors
- Send multiple test messages interactively

### Batch Mode
```bash
python test_setpoint_mqtt.py --mode batch
```

This mode runs predefined test scenarios:
- Temperature tests (pass, over threshold, under threshold)
- Humidity tests (pass, over threshold, under threshold)

### Random Mode
```bash
python test_setpoint_mqtt.py --mode random --count 20
```

This mode sends random test values:
- `--count` specifies how many random tests to run
- Generates random setpoint and current values
- Tests both temperature and humidity

## Command Line Options

- `--broker` - MQTT broker address (default: localhost)
- `--port` - MQTT broker port (default: 1883)
- `--mode` - Test mode: interactive, batch, or random (default: interactive)
- `--count` - Number of random tests for random mode (default: 10)

## Example MQTT Messages

The script sends messages in this format:

```json
{
  "sensor_id": "temp_room_01",
  "sensor_type": "temperature",
  "setpoint": 22.0,
  "value": 23.5,
  "unit": "°C",
  "timestamp": "2024-01-15T10:30:00.123456",
  "test_mode": true
}
```

## Topics

Messages are sent to topics in the format:
- `sensors/temperature/{sensor_id}`
- `sensors/humidity/{sensor_id}`

## Testing Your Diagnostic Codes

1. Create diagnostic codes with setpoint strategy in your web interface
2. Set the MQTT JSON field to `"setpoint"` for the setpoint value
3. Run this test script to send test data
4. Check your dashboard to see if the diagnostic codes respond correctly

## Troubleshooting

- Make sure MQTT broker is running
- Check that the topic format matches your MQTT listener configuration
- Verify that the JSON field names match your diagnostic code configuration
- Check the MQTT listener logs for message processing
