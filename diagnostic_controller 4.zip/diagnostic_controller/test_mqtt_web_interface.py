#!/usr/bin/env python3
"""
Test script for MQTT Web Interface
"""

import requests
import json
import time

def test_mqtt_web_interface():
    base_url = "http://localhost:5001"
    
    print("Testing MQTT Web Interface...")
    print("=" * 50)
    
    # Test 1: Check if the MQTT listener page is accessible
    print("\n1. Testing MQTT Listener page access...")
    try:
        response = requests.get(f"{base_url}/mqtt_listener")
        if response.status_code == 200:
            print("✓ MQTT Listener page is accessible")
        else:
            print(f"✗ MQTT Listener page returned status code: {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("✗ Could not connect to the application. Make sure it's running on port 5001")
        return
    except Exception as e:
        print(f"✗ Error accessing MQTT Listener page: {e}")
    
    # Test 2: Check MQTT status API
    print("\n2. Testing MQTT Status API...")
    try:
        response = requests.get(f"{base_url}/api/mqtt/status")
        if response.status_code == 200:
            data = response.json()
            print(f"✓ MQTT Status API working")
            print(f"  - Connected: {data.get('connected', 'N/A')}")
            print(f"  - Broker: {data.get('broker', 'N/A')}")
            print(f"  - Port: {data.get('port', 'N/A')}")
            print(f"  - Topic: {data.get('topic', 'N/A')}")
        else:
            print(f"✗ MQTT Status API returned status code: {response.status_code}")
    except Exception as e:
        print(f"✗ Error accessing MQTT Status API: {e}")
    
    # Test 3: Check MQTT Messages API
    print("\n3. Testing MQTT Messages API...")
    try:
        response = requests.get(f"{base_url}/api/mqtt/messages")
        if response.status_code == 200:
            data = response.json()
            print(f"✓ MQTT Messages API working")
            print(f"  - Messages count: {len(data.get('messages', []))}")
        else:
            print(f"✗ MQTT Messages API returned status code: {response.status_code}")
    except Exception as e:
        print(f"✗ Error accessing MQTT Messages API: {e}")
    
    # Test 4: Test MQTT Connect API (without actually connecting)
    print("\n4. Testing MQTT Connect API structure...")
    try:
        # This will fail without proper authentication, but we can check the endpoint exists
        response = requests.post(f"{base_url}/api/mqtt/connect", 
                               json={"broker": "test", "port": 1883, "topic": "#"})
        if response.status_code in [401, 403]:  # Unauthorized/Forbidden is expected without login
            print("✓ MQTT Connect API endpoint exists (authentication required)")
        else:
            print(f"✓ MQTT Connect API returned status code: {response.status_code}")
    except Exception as e:
        print(f"✗ Error testing MQTT Connect API: {e}")
    
    # Test 5: Test MQTT Disconnect API
    print("\n5. Testing MQTT Disconnect API structure...")
    try:
        response = requests.post(f"{base_url}/api/mqtt/disconnect")
        if response.status_code in [401, 403]:  # Unauthorized/Forbidden is expected without login
            print("✓ MQTT Disconnect API endpoint exists (authentication required)")
        else:
            print(f"✓ MQTT Disconnect API returned status code: {response.status_code}")
    except Exception as e:
        print(f"✗ Error testing MQTT Disconnect API: {e}")
    
    print("\n" + "=" * 50)
    print("Test completed!")
    print("\nTo test the full functionality:")
    print("1. Start the Flask application: python app.py")
    print("2. Open http://localhost:5001 in your browser")
    print("3. Log in to access the MQTT Listener")
    print("4. Navigate to the MQTT Listener page")
    print("5. Configure broker settings and test connection")

if __name__ == "__main__":
    test_mqtt_web_interface()
